<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mobile Cart</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    /* Custom Navbar Background */
    .custom-navbar {
      background-color: #333; /* Change this to any color */
    }

    /* Custom Text Color */
    .custom-navbar .navbar-nav .nav-link,
    .custom-navbar .navbar-brand,
    .custom-navbar .dropdown-menu a {
      color: #fff !important; /* White text */
    }

    .custom-navbar .navbar-brand img {
      height: 40px;
      margin-right: 10px;
    }
    .rounded-logo {
  height: 50px;
  width: 50px;
  border-radius: 50%;
  object-fit: cover;
  margin-right: 10px;
}

   .custom-navbar .dropdown-menu {
  background-color: #333; /* Dark background */
  border: none;
}

.custom-navbar .dropdown-menu .dropdown-item {
  color: #f8f9fa; /* Light text */
}

.custom-navbar .dropdown-menu .dropdown-item:hover {
  background-color: #0d6efd; /* Bootstrap primary blue */
  color: #fff;
}


    /* Optional: Outline button color (Login) */
    .custom-navbar .btn-outline-light {
      color: #fff;
      border-color: #fff;
    }

    .custom-navbar .btn-outline-light:hover {
      background-color: #fff;
      color: #0d6efd;
    }
  </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark custom-navbar">
  <div class="container-fluid">
    <!-- Replace inside your navbar-brand -->
<a class="navbar-brand d-flex align-items-center" href="./index.php">
 
  Mobile Cart
</a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item"><a class="nav-link" href="./index.php">Home</a></li>

        <li class="nav-item dropdown">
<a class="nav-link dropdown-toggle" href="#" id="shopDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
  Shop
</a>
          
          <ul class="dropdown-menu" aria-labelledby="shopDropdown">
            <li><a class="dropdown-item" href="./phone_cases.php?category=Phone Case">Phone Case</a></li>
            <li><a class="dropdown-item" href="./chargers.php?category=Chargers">Chargers</a></li>
            <li><a class="dropdown-item" href="./audio.php?category=Audio">Audio</a></li>
            <li><a class="dropdown-item" href="./cables.php?category=Cables">Cables</a></li>
          </ul>
        </li>

        <li class="nav-item"><a class="nav-link" href="./cart.php">Cart</a></li>
        <li class="nav-item"><a class="nav-link" href="./about.php">About</a></li>
        <li class="nav-item"><a class="nav-link" href="./contact.php">Contact Us</a></li>
        <li class="nav-item"><a class="nav-link" href="./track_order.php">Track Order</a></li>
        <li class="nav-item"><a class="btn btn-outline-light" href="./login.php">Login</a></li>
      </ul>
    </div>
  </div>
</nav>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
