<?php
session_start();
include "./navdash.php";
require 'db1.php'; // Database connection

// Fetch orders (assuming product name is directly in orders table now)
try {
    $query = "SELECT order_id, created_at, total_amount, product, quantity 
              FROM orders 
              ORDER BY created_at DESC, order_id DESC";
    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<div class='alert alert-danger'>Error fetching orders: " . htmlspecialchars($e->getMessage()) . "</div>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders</title>

    <!-- Bootstrap CSS (Latest 5.3.3) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome (Optional) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<div class="container mt-5">
        <div class="card-header  text-black">
            <h2>Order History</h2>
        </div>
        <br>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-bordered align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>Order ID</th>
                            <th>Products</th>
                            <th>Order Date</th>
                            <th>Total Amount (Rs.)</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    if (!empty($orders)) {
                        $current_order_id = null;
                        $product_list = [];
                        $created_at = '';
                        $total_amount = 0;

                        foreach ($orders as $order) {
                            if ($current_order_id !== $order['order_id']) {
                                // Display the previous order row
                                if ($current_order_id !== null) {
                                    echo "<tr><td>{$current_order_id}</td><td><ul class='mb-0'>";
                                    foreach ($product_list as $product) {
                                        echo "<li>{$product['name']}</li>";
                                    }
                                    echo "</ul></td><td>{$created_at}</td><td>" . number_format($total_amount, 2) . "</td></tr>";
                                }
                                // Start new order
                                $current_order_id = $order['order_id'];
                                $created_at = $order['created_at'];
                                $total_amount = $order['total_amount'];
                                $product_list = [];
                            }
                            $product_list[] = ['name' => $order['product'], 'quantity' => $order['quantity']];
                        }

                        // Display the last order
                        if ($current_order_id !== null) {
                            echo "<tr><td>{$current_order_id}</td><td><ul class='mb-0'>";
                            foreach ($product_list as $product) {
                                echo "<li>{$product['name']}</li>";
                            }
                            echo "</ul></td><td>{$created_at}</td><td>" . number_format($total_amount, 2) . "</td></tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4' class='text-center'>No orders found.</td></tr>";
                    }
                    ?>
                    </tbody>
                </table>
            </div>
            <a href="dashboard.php" class="btn btn-primary mt-3">
                <i class="fas fa-arrow-left me-1"></i>Back to Home
            </a>
        </div>
    </div>
</div>
<br>    
<!-- Bootstrap Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<?php include 'footer.php'; ?>
</body>
</html>
