<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/Exception.php';

$mail = new PHPMailer(true);

try {
    // SMTP settings
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'your_email@gmail.com';      // Your Gmail address
    $mail->Password   = 'your_app_password';         // Gmail App Password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    // Sender & Recipient
    $mail->setFrom('your_email@gmail.com', 'Mobile Cart Test');
    $mail->addAddress('recipient_email@gmail.com', 'Admin');

    // Content
    $mail->isHTML(true);
    $mail->Subject = 'Test Email from Mobile Cart';
    $mail->Body    = '✅ This is a test email sent using PHPMailer & Gmail SMTP.';
    $mail->AltBody = 'This is a plain-text version of the email.';

    $mail->send();
    echo '✅ Test email sent successfully!';
} catch (Exception $e) {
    echo "❌ Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
